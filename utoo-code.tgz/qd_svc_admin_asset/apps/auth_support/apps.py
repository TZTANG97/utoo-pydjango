from django.apps import AppConfig


class AuthSupportConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.auth_support"
